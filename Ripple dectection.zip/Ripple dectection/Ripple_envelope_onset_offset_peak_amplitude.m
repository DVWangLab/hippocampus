% Import ripple (100-250 Hz band-pass filtered)
clearvars -except ripple

% Ripple envelope calculation
a1 = envelope(ripple(:,1));  

% Gaussian smoothing (SD = 4ms; Karlsson & Frank, 2009)
SD = 4; 
w = gausswin(SD*5 + 1, SD); 
w = w / sum(w);  
a2 = conv(a1, w, 'same');

% Combine ripple envelope with timestamps
ripple_envelope(:,1) = a2;  
ripple_envelope(:,2) = ripple(:,2);

% Assign ripple envelope to AA for further processing
AA = ripple_envelope;

% Ripple envelope threshold (5 SD above mean)
TH5 = 5 * std(AA(:,1)) + mean(AA(:,1));  
BB = AA(AA(:,1) > TH5, :);  

% Identify ripple peaks with >0.05s separation
CC(1,:) = BB(1,:);  
j = 1;
for i = 1:length(BB) - 1
    if BB(i+1,2) - BB(i,2) > 0.05       
        CC(j+1,:) = BB(i+1,:); 
        j = j + 1;
    end
end

% Refine ripple peak selection with 0.1s criteria
j = 1;  
for i = 1:length(CC)
    DD(i,:) = CC(i,:);
    for j = j:length(BB)          
        if BB(j,2) - CC(i,2) > 0 && BB(j,2) - CC(i,2) < 0.1 && BB(j,1) - DD(i,1) > 0  
            DD(i,:) = BB(j,:);
        elseif BB(j,2) - CC(i,2) > 0.1  
            break; 
        end
    end
end

% Extract ripple amplitude and peak timestamps
ripple_amplitude = DD(:,1);  
ripple_peak = DD(:,2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Ripple envelope threshold (1 SD above mean)
TH = std(AA(:,1)) + mean(AA(:,1));  
BB2 = AA(AA(:,1) > TH, :);  

% Identify ripple onsets with >0.01s separation
CC2(1,:) = BB2(1,:);  
j = 1;
for i = 1:length(BB2) - 1
    if BB2(i+1,2) - BB2(i,2) > 0.01       
        CC2(j+1,:) = BB2(i+1,:); 
        DD2(j,:) = BB2(i,:);  
        j = j + 1;
    end
end
DD2(j,:) = BB2(end,:);

% Determine ripple onset and offset
j = 1; k = 1;
for i = 1:length(CC)
    for j = j:length(CC2)
        if CC2(j,2) - CC(i,2) > 0  
            ripple_onset(k,1) = CC2(j-1,2);  
            ripple_offset(k,1) = DD2(j-1,2);  
            k = k + 1; 
            break;
        end
    end
end

% Clean up workspace, retaining essential variables
clearvars -except ripple ripple_envelope ripple_onset ripple_offset ripple_peak ripple_amplitude